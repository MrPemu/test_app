export interface IRandomImageText {
    id: number,
    photo: string,
    text: string
}
